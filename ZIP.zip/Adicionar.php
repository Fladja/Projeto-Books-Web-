<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>BooksWeb Oficial</title>
  <link rel="stylesheet" type="text/css" href="css.css">
  <link rel="icon" type="image" href="logotipo.png">
</head>
<body>
  <div class = "quadrado4">

    <?php
        echo "<body><h1> Livro adicionado com sucesso!</h1></body>";

        $titulo = $_POST['titulo'];
        $genero = $_POST['genero'];
        $autor = $_POST['autor'];
        $ano = $_POST['ano'];
        $sinopse = $_POST['sinopse'];

        echo "<p><b> Título:</b> $titulo </p>";
        echo "<p><b> Gênero:</b> $genero </p>";
        echo "<p><b> Autor:</b> $autor </p>";
        echo "<p><b> Ano:</b> $ano </p>";
        echo "<p><b> Sinopse:</b> $sinopse </p>";

        $banco1 = new SQLite3("BDlivros.db");

        $banco1 -> exec("CREATE TABLE IF NOT EXISTS livros(titulo TEXT)");
        $banco1 -> exec("CREATE TABLE IF NOT EXISTS livros(genero TEXT)");
        $banco1 -> exec("CREATE TABLE IF NOT EXISTS livros(autor TEXT)");
        $banco1 -> exec("CREATE TABLE IF NOT EXISTS livros(ano NUMBER)");
        $banco1 -> exec("CREATE TABLE IF NOT EXISTS livros(sinopse TEXT)");

      $banco1 -> exec("INSERT INTO livros VALUES('" . $titulo . "')");
      $banco1 -> exec("INSERT INTO livros VALUES('" . $genero . "')");
      $banco1 -> exec("INSERT INTO livros VALUES('" . $autor . "')");
      $banco1 -> exec("INSERT INTO livros VALUES('" . $ano . "')");
      $banco1 -> exec("INSERT INTO livros VALUES('" . $sinopse . "')");

    ?>
  </div>
</body>
</html>
