function validaDados(){
  var usu = document.getElementById("input_usuario").value
  var senha = document.getElementById("input_senha").value
  
    for(i in usuarios){
      if(usuarios[i]["username"] == usu){
          if(usuarios[i]["password"] == senha){
            window.location.href="tela3.html";
            return;
          }else{
            alert('usuário ou senha inválidos');
            return;
          }
        }
      }
    alert('não encontrou usuário compatível');
  }
