<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
 	 <title>BooksWeb Oficial</title>
  	<link rel="stylesheet" type="text/css" href="css.css">
 	 <link rel="icon" type="image" href="logotipo.png">
<body>
	<div class = "quadrado8">
		<h1>Feedback cadastrado com sucesso!</h1>
	<?php

		$titulo2 = $_POST['title'];
		$FB = $_POST['feedback'];

		echo "<p><b>Título:</b>$titulo2</p>";
		echo "<p><b>Feedback:</b>$FB</p>";

		$banco2 = new SQLite3 ("BDfeedbacks.db");
		$banco2 -> exec("CREATE TABLE IF NOT EXISTS feedbacks(titulo TEXT)");
		$banco2 -> exec("CREATE TABLE IF NOT EXISTS feedbacks(feedbacks TEXT)");

		$banco2 -> exec("INSERT INTO feedbacks VALUES('" . $titulo2. "')");
		$banco2 -> exec("INSERT INTO feedbacks VALUES('" . $FB . "')");

		?>
		<a href = "tela3.html">Clique aqui para retornar ao menu</a>
	</div>
</body>
</html>