//banco de dados para guardar os logins dos usuários
usuario1={
  username:"Gabriel",
  password:"1839"
};
usuario2={
	username:"Eduarda",
	password:"8291"
};
usuario3={
	username:"Mariana",
	password:"1827"
};
usuario4={
	username:"Ste", 
	password:"1307"
};

usuarios={usuario1, usuario2, usuario3, usuario4};
