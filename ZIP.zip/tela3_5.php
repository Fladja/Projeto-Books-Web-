<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	 <title>BooksWeb Oficial</title>
	 <link rel="stylesheet" type="text/css" href="css.css">
   	<link rel="icon" type="image" href="logotipo.png">
   </head>
</head>
<body>
	<div class = "quadrado9">
	<h1>Feedbacks cadastrados</h1>
	<?php
		$banco2 = new SQLite3("BDfeedbacks.db");

		 $exibe_dados2 = $banco2 -> query("SELECT * FROM feedbacks");

		while($value2 = $exibe_dados2 -> fetchArray()){
			echo "<p>" . $value2['titulo'] . "</p><hr>";
		}
	 ?>
	</div>
</body>
</html>