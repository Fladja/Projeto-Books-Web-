<!DOCTYPE html>
<html>
  <head>
	    <meta charset="utf-8">
	    <title>BooksWeb Oficial</title>
	    <link rel="stylesheet" type="text/css" href="css.css">
    	<link rel="icon" type="image" href="logotipo.png">
   </head>
   <body>
   	<div class = "quadrado5">
   		<h1>Livros cadastrados</h1>
		<?php

		$banco1 = new SQLite3("BDlivros.db");

		 $exibe_dados1 = $banco1 -> query("SELECT * FROM livros");

		while($value1 = $exibe_dados1 -> fetchArray()){
			echo "<p>" . $value1['titulo'] . "</p><hr>";
		}
		?>
		<a href = "tela3.html">Clique aqui para voltar ao menu</a>
	</div>
</body>